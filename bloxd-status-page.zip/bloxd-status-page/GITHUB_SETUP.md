# GitHub Deployment Guide

This is a complete setup guide for deploying Bloxd.io Status Page to GitHub and beyond.

## Local Development Setup

### Prerequisites
- Python 3.11+
- pip or uv package manager

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/bloxd-status.git
   cd bloxd-status
   ```

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Set up environment variables**
   Create a `.env` file in the root directory:
   ```bash
   RESEND_API_KEY=your_resend_api_key_here
   RESEND_FROM_EMAIL=noreply@yourdomain.com
   ```
   
   Get your Resend API key from: https://resend.com

4. **Run the application**
   ```bash
   # Start both frontend and backend
   python app.py &
   python -m http.server 5000 --bind 0.0.0.0
   ```
   
   Or run them in separate terminals:
   ```bash
   # Terminal 1: Backend API
   python app.py
   
   # Terminal 2: Frontend server
   python -m http.server 5000 --bind 0.0.0.0
   ```

5. **Access the app**
   - Frontend: http://localhost:5000
   - Backend: http://localhost:8000

## Deployment Options

### Option 1: Heroku

1. **Install Heroku CLI**
   ```bash
   npm install -g heroku
   heroku login
   ```

2. **Create Heroku app**
   ```bash
   heroku create your-app-name
   ```

3. **Set environment variables**
   ```bash
   heroku config:set RESEND_API_KEY=your_key_here
   heroku config:set RESEND_FROM_EMAIL=noreply@yourdomain.com
   ```

4. **Deploy**
   ```bash
   git push heroku main
   ```

### Option 2: Render

1. **Connect your GitHub repo** to Render.com
2. **Create new Web Service**
3. **Set these environment variables**:
   - `RESEND_API_KEY`: Your Resend API key
   - `RESEND_FROM_EMAIL`: Your sender email
4. **Deploy** (auto-deploys on git push)

### Option 3: Railway

1. **Connect GitHub** to Railway.app
2. **Create new project from repository**
3. **Add environment variables** in Railway dashboard
4. **Deploy** automatically

### Option 4: AWS / Replit / Other Platforms

1. Push code to GitHub
2. Connect platform to GitHub repo
3. Set environment variables in platform dashboard
4. Deploy

## GitHub Actions (Optional CI/CD)

Create `.github/workflows/deploy.yml` to auto-deploy on push:

```yaml
name: Deploy to Render

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Deploy to Render
        run: |
          curl -X POST ${{ secrets.RENDER_DEPLOY_HOOK }}
```

Get your Render deploy hook from: Render dashboard → Settings → Deploy Hook

## API Documentation

### Subscribe to Updates
```bash
curl -X POST http://localhost:8000/api/subscribe \
  -H "Content-Type: application/json" \
  -d '{"email": "user@example.com"}'
```

### Send Disruption Notification
```bash
curl -X POST http://localhost:8000/api/notify-disruption \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Database Outage",
    "description": "Database is offline",
    "affected_services": ["Database", "API"]
  }'
```

### Test Email System
```bash
curl -X POST http://localhost:8000/api/test-notification
```

### Health Check
```bash
curl http://localhost:8000/health
```

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `RESEND_API_KEY` | Yes | Resend email API key (get from resend.com) |
| `RESEND_FROM_EMAIL` | No | Sender email address (defaults to noreply@resend.dev) |
| `FLASK_ENV` | No | Set to 'production' for deployments |
| `PORT` | No | Backend port (defaults to 8000) |

## File Structure

```
bloxd-status/
├── app.py                 # Flask backend API
├── index.html             # Frontend HTML
├── script.js              # Frontend JavaScript
├── styles.css             # Frontend CSS
├── data.js                # Service/incident data
├── requirements.txt       # Python dependencies
├── Procfile               # Heroku deployment config
├── runtime.txt            # Python version
├── GITHUB_SETUP.md        # This file
└── replit.md              # Replit-specific info
```

## Troubleshooting

### "RESEND_API_KEY not found" error
- Make sure you've set the environment variable in your platform
- Check your Resend account is active and API key is valid

### Frontend not loading
- Ensure the HTTP server is running on port 5000
- Check browser console for errors
- Verify CORS is enabled (already configured in app.py)

### Emails not sending
- Verify Resend API key is correct
- Check backend logs for errors
- Use `/api/test-notification` endpoint to test

### Port already in use
- Backend uses port 8000: `lsof -i :8000` to check
- Frontend uses port 5000: `lsof -i :5000` to check
- Kill processes: `kill -9 <PID>`

## Support

For issues with:
- **Resend**: https://resend.com/docs
- **Flask**: https://flask.palletsprojects.com/
- **Heroku**: https://devcenter.heroku.com/
- **This project**: Check the replit.md file

## License

Check UNLICENSE.md for more infomation.
