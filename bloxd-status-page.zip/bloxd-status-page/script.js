// Theme toggle
const themeToggle = document.getElementById('themeToggle');
const htmlElement = document.documentElement;

// Load theme preference from localStorage
const savedTheme = localStorage.getItem('theme');
if (savedTheme === 'dark' || (!savedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
    document.body.classList.add('dark-mode');
    themeToggle.textContent = '☀️';
}

themeToggle.addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
    const isDarkMode = document.body.classList.contains('dark-mode');
    localStorage.setItem('theme', isDarkMode ? 'dark' : 'light');
    themeToggle.textContent = isDarkMode ? '☀️' : '🌙';
});

// Subscription form
const subscriptionForm = document.getElementById('subscriptionForm');
const emailInput = document.getElementById('emailInput');
const subscriptionNote = document.getElementById('subscriptionNote');

const API_BASE = window.location.origin === 'http://localhost:5000' 
    ? 'http://localhost:8000/api'
    : `${window.location.origin.replace(':5000', ':8000')}/api`;

subscriptionForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = emailInput.value;
    
    try {
        const response = await fetch(`${API_BASE}/subscribe`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            subscriptionNote.textContent = '✓ Subscribed successfully! Check your email for confirmation.';
            subscriptionNote.style.color = 'var(--success-color)';
            emailInput.value = '';
            setTimeout(() => {
                subscriptionNote.textContent = '';
            }, 5000);
        } else if (data.already_subscribed) {
            subscriptionNote.textContent = 'You are already subscribed with this email.';
            subscriptionNote.style.color = 'var(--warning-color)';
        } else {
            subscriptionNote.textContent = data.error || 'Subscription failed';
            subscriptionNote.style.color = 'var(--danger-color)';
        }
    } catch (error) {
        subscriptionNote.textContent = 'Error subscribing. Please try again.';
        subscriptionNote.style.color = 'var(--danger-color)';
        console.error('Subscription error:', error);
    }
});

// Render services
function renderServices() {
    const servicesContainer = document.getElementById('servicesContainer');
    servicesContainer.innerHTML = '';

    services.forEach(service => {
        const serviceCard = document.createElement('div');
        serviceCard.className = 'service-card';
        
        const statusClass = `status-${service.status.replace(/\s+/g, '-').toLowerCase()}`;
        
        const header = document.createElement('div');
        header.className = 'service-header';
        
        const nameDiv = document.createElement('div');
        nameDiv.className = 'service-name';
        nameDiv.textContent = service.name;
        
        const statusDiv = document.createElement('div');
        statusDiv.className = `service-status ${statusClass}`;
        const dot = document.createElement('span');
        dot.className = 'status-dot';
        const statusText = document.createTextNode(service.status);
        statusDiv.appendChild(dot);
        statusDiv.appendChild(statusText);
        
        header.appendChild(nameDiv);
        header.appendChild(statusDiv);
        
        const descDiv = document.createElement('p');
        descDiv.className = 'service-description';
        descDiv.textContent = service.description;
        
        serviceCard.appendChild(header);
        serviceCard.appendChild(descDiv);
        servicesContainer.appendChild(serviceCard);
    });

    updateOverallStatus();
}

// Update overall status
function updateOverallStatus() {
    const statuses = services.map(s => s.status);
    const hasOutage = statuses.includes('Major Outage');
    const hasPartial = statuses.includes('Partial Outage');
    const hasDegraded = statuses.includes('Degraded Performance');
    const hasMaintenance = statuses.includes('Maintenance');

    let overallStatus, statusIndicatorClass;

    if (hasOutage) {
        overallStatus = 'Major Outage';
        statusIndicatorClass = 'major';
    } else if (hasPartial) {
        overallStatus = 'Partial Outage';
        statusIndicatorClass = 'partial';
    } else if (hasDegraded) {
        overallStatus = 'Degraded Performance';
        statusIndicatorClass = 'degraded';
    } else if (hasMaintenance) {
        overallStatus = 'Maintenance in Progress';
        statusIndicatorClass = 'maintenance';
    } else {
        overallStatus = 'All Systems Operational';
        statusIndicatorClass = 'operational';
    }

    const overallStatusEl = document.getElementById('overallStatus');
    overallStatusEl.textContent = overallStatus;
    
    // Update status indicator
    const statusIndicator = document.querySelector('.overall-status .status-indicator');
    if (statusIndicator) {
        statusIndicator.className = `status-indicator ${statusIndicatorClass}`;
    }
}

// Render incidents
function renderIncidents() {
    const incidentsList = document.getElementById('incidentsList');
    const activeIncidents = incidents.filter(i => i.status !== 'Resolved');

    if (activeIncidents.length === 0) {
        incidentsList.innerHTML = '<div class="no-incidents"><p>No active incidents</p></div>';
        return;
    }

    incidentsList.innerHTML = '';
    activeIncidents.forEach(incident => {
        const incidentCard = document.createElement('div');
        incidentCard.className = `incident-card ${incident.status.toLowerCase()}`;
        
        const startTime = new Date(incident.startTime).toLocaleString();
        const affectedServices = incident.affectedServices.join(', ');

        const headerDiv = document.createElement('div');
        headerDiv.className = 'incident-header';
        
        const titleDiv = document.createElement('div');
        titleDiv.className = 'incident-title';
        titleDiv.textContent = incident.title;
        
        const badge = document.createElement('span');
        badge.className = `incident-badge badge-${incident.status.toLowerCase()}`;
        badge.textContent = incident.status;
        
        headerDiv.appendChild(titleDiv);
        headerDiv.appendChild(badge);
        
        const timeDiv = document.createElement('div');
        timeDiv.className = 'incident-time';
        timeDiv.textContent = startTime;
        
        const descDiv = document.createElement('div');
        descDiv.className = 'incident-description';
        descDiv.textContent = incident.description;
        
        const affectedDiv = document.createElement('div');
        affectedDiv.className = 'incident-affected';
        const affectedLabel = document.createElement('strong');
        affectedLabel.textContent = 'Affected Services: ';
        affectedDiv.appendChild(affectedLabel);
        affectedDiv.appendChild(document.createTextNode(affectedServices));
        
        incidentCard.appendChild(headerDiv);
        incidentCard.appendChild(timeDiv);
        incidentCard.appendChild(descDiv);
        incidentCard.appendChild(affectedDiv);
        incidentsList.appendChild(incidentCard);
    });
}

// Render history
function renderHistory(filter = 'all') {
    const historyList = document.getElementById('historyList');
    let filteredIncidents = incidents;

    if (filter === 'resolved') {
        filteredIncidents = incidents.filter(i => i.status === 'Resolved');
    } else if (filter === 'maintenance') {
        filteredIncidents = incidents.filter(i => i.type === 'Maintenance');
    }

    historyList.innerHTML = '';
    
    if (filteredIncidents.length === 0) {
        historyList.innerHTML = '<p style="text-align: center; color: #6b7280;">No incidents found</p>';
        return;
    }

    filteredIncidents.forEach(incident => {
        const historyItem = document.createElement('div');
        historyItem.className = `history-item ${incident.status.toLowerCase()}`;
        
        const startDate = new Date(incident.startTime).toLocaleDateString();
        const endDate = incident.endTime ? new Date(incident.endTime).toLocaleDateString() : 'Ongoing';
        const duration = incident.endTime 
            ? `${Math.floor((new Date(incident.endTime) - new Date(incident.startTime)) / (1000 * 60))} minutes`
            : 'In progress';

        const dateDiv = document.createElement('div');
        dateDiv.className = 'history-date';
        dateDiv.textContent = startDate;
        
        const titleDiv = document.createElement('div');
        titleDiv.className = 'history-title';
        titleDiv.textContent = incident.title;
        
        const durationDiv = document.createElement('div');
        durationDiv.className = 'history-duration';
        const durationLabel = document.createElement('strong');
        durationLabel.textContent = 'Duration: ';
        durationDiv.appendChild(durationLabel);
        durationDiv.appendChild(document.createTextNode(duration));
        
        historyItem.appendChild(dateDiv);
        historyItem.appendChild(titleDiv);
        historyItem.appendChild(durationDiv);
        historyList.appendChild(historyItem);
    });
}

// Filter buttons
document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        renderHistory(btn.dataset.filter);
    });
});

// Initialize
renderServices();
renderIncidents();
renderHistory();

// Refresh data every 30 seconds
setInterval(() => {
    renderServices();
    renderIncidents();
}, 30000);
