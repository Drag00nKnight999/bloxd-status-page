# Bloxd.io Status Page with Email Notifications

## Overview
A real-time status page for Bloxd.io with email notification system for service disruptions.

## Features Completed
- **Frontend Status Page**: Beautiful, responsive status page with dark mode
- **Email Subscriptions**: Users can subscribe to email updates about service disruptions
- **Automated Notifications**: Backend automatically sends emails when services go down
- **Service Status Tracking**: Monitor 6 core services (Game Servers, Website, API, Auth, Database, CDN)
- **Incident History**: Track past incidents and maintenance windows
- **Resend Integration**: Uses Resend email service for reliable email delivery

## Project Structure
```
.
├── index.html          # Main status page HTML
├── script.js           # Frontend JavaScript (subscription + rendering)
├── styles.css          # Responsive CSS with dark mode
├── data.js             # Service and incident data
├── app.py              # Flask backend API
├── subscribers.json    # Stored email subscribers (auto-created)
├── status.json         # Status tracking file (auto-created)
└── replit.md          # This file
```

## Backend API Endpoints

### Subscribe to Updates
**POST** `/api/subscribe`
```json
{
  "email": "user@example.com"
}
```
Response:
- `201`: Successfully subscribed, confirmation email sent
- `200`: Already subscribed
- `400`: Invalid email

### Send Disruption Notification
**POST** `/api/notify-disruption`
```json
{
  "title": "Database Outage",
  "description": "Database is offline due to maintenance",
  "affected_services": ["Database", "API"]
}
```
Sends emails to all subscribers about the disruption.

### Test Notification (Development)
**POST** `/api/test-notification`
Sends a test disruption email to all subscribers to verify the email system is working.

### Health Check
**GET** `/api/health`
Returns `{"status": "ok"}` to verify the backend is running.

## How to Use

### 1. Frontend (Port 5000)
- Users can visit the status page and see all services
- Subscribe box sends email to backend API
- User gets confirmation email from Resend
- Dark/light mode toggle available

### 2. Backend (Port 8000)
- Handles subscription management
- Sends emails via Resend service
- Stores subscribers in `subscribers.json`
- Can be triggered to send notifications

### 3. Email System
- Uses **Resend** integration (already connected)
- Sends confirmation email when user subscribes
- Sends alert emails when you trigger a disruption notification
- All email from configured Resend sender address

## Testing Email System

1. **Subscribe a test email**:
   - Go to the status page
   - Enter an email in the "Get Notifications" box
   - Click Subscribe
   - Check email for confirmation

2. **Send test disruption notification**:
   ```bash
   curl -X POST http://localhost:8000/api/test-notification \
     -H "Content-Type: application/json" \
     -d '{"title":"Test Alert","description":"This is a test","affected_services":["Database"]}'
   ```

## Managing Services & Incidents

Edit `data.js` to:
- Add/remove services
- Update service statuses
- Add incident records

Example incident to add to `data.js`:
```javascript
{
  title: 'Database Performance Degradation',
  description: 'Database query times elevated',
  status: 'Investigating',
  type: 'Outage',
  affectedServices: ['Database', 'API'],
  startTime: '2025-11-30T18:00:00Z',
  endTime: '2025-11-30T19:00:00Z'
}
```

## Current Setup
- Frontend: Python HTTP server on port 5000
- Backend: Flask app on port 8000
- Email Service: Resend (connected via Replit integration)
- Storage: JSON files (subscribers.json, status.json)

## Environment Variables
- `REPLIT_CONNECTORS_HOSTNAME`: Auto-set by Replit (for Resend connection)
- `REPL_IDENTITY`: Auto-set by Replit (for authentication)
- `RESEND_API_KEY`: Retrieved from Replit Resend connector
