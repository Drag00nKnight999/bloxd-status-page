# Bloxd.io Status Page with Email Notifications

A professional real-time status page for Bloxd.io with automated email notifications for service disruptions.

## Features

✅ **Real-time Status Dashboard**
- Beautiful, responsive status page with dark mode
- Monitor 6 core services (Game Servers, Website, API, Authentication, Database, CDN)
- Overall system health indicator with uptime stats

✅ **Email Notification System**
- Users subscribe to email updates
- Automatic confirmation emails via Resend
- Alert emails sent when services go down
- Subscriber management API

✅ **Incident Tracking**
- Track active incidents and disruptions
- Maintain historical incident logs
- Filter by status (All, Resolved, Maintenance)
- Display affected services for each incident

✅ **Production Ready**
- Easy GitHub deployment to Heroku, Render, Railway, AWS
- Runs locally or on any platform
- Configurable environment variables
- CORS enabled for all environments

## Quick Start

### Local Development (5 minutes)

```bash
# 1. Clone & install
git clone https://github.com/yourusername/bloxd-status.git
cd bloxd-status
pip install -r requirements.txt

# 2. Set up Resend API key
# Get free key from https://resend.com
cp .env.example .env
# Edit .env with your Resend API key

# 3. Run it
python app.py &
python -m http.server 5000 --bind 0.0.0.0

# 4. Open browser
# Frontend: http://localhost:5000
# Backend: http://localhost:8000
```

### Deploy to GitHub

#### Option 1: Heroku (Easiest)
```bash
heroku create your-app-name
heroku config:set RESEND_API_KEY=your_key_here
git push heroku main
```

#### Option 2: Render.com
1. Connect GitHub repo to Render
2. Create Web Service
3. Add environment variables
4. Deploy

#### Option 3: Railway.app
1. Import GitHub repo
2. Add `RESEND_API_KEY` secret
3. Deploy automatically

See [GITHUB_SETUP.md](GITHUB_SETUP.md) for detailed deployment guides.

## API Endpoints

### Subscribe to Email Updates
```bash
POST /api/subscribe
Content-Type: application/json

{"email": "user@example.com"}
```

### Send Service Disruption Alert
```bash
POST /api/notify-disruption
Content-Type: application/json

{
  "title": "Database Outage",
  "description": "Database is experiencing connectivity issues",
  "affected_services": ["Database", "API"]
}
```

### Test Email System
```bash
POST /api/test-notification
```

### Get All Subscribers
```bash
GET /api/subscribers
```

### Health Check
```bash
GET /health
```

## Configuration

### Required Environment Variables
- `RESEND_API_KEY` - Resend email service API key (free at https://resend.com)

### Optional Environment Variables
- `RESEND_FROM_EMAIL` - Sender email address (defaults to `noreply@resend.dev`)
- `FLASK_ENV` - Set to `production` for deployments
- `PORT` - Backend port (defaults to 8000)

### Getting a Resend API Key
1. Go to https://resend.com
2. Sign up (free account)
3. Verify email
4. Create API key in dashboard
5. Copy to your `.env` file or platform environment variables

## Project Structure

```
bloxd-status/
├── app.py                 # Flask backend API
├── index.html             # Frontend HTML
├── script.js              # Frontend JavaScript & subscriptions
├── styles.css             # Responsive design + dark mode
├── data.js                # Service & incident data
├── requirements.txt       # Python dependencies
├── Procfile               # Heroku/Platform deployment config
├── runtime.txt            # Python version
├── .env.example           # Example environment variables
├── README.md              # This file
├── GITHUB_SETUP.md        # Deployment guide
├── subscribers.json       # Stored email subscribers (auto-created)
└── status.json            # Status tracking (auto-created)
```

## Usage

### For Status Page Users
1. Visit your status page URL
2. Enter email in "Get Notifications" box
3. Click Subscribe
4. Check email for confirmation
5. Receive alerts when services go down

### For Administrators
1. Edit `data.js` to manage services and incidents
2. Call `/api/notify-disruption` endpoint to send alerts
3. Use `/api/test-notification` to verify email system works
4. Access `/api/subscribers` to see subscriber count

### Example: Add an Incident
Edit `data.js` and add to incidents array:
```javascript
{
  title: 'API Slowdown',
  description: 'API is experiencing elevated response times',
  status: 'Investigating',
  type: 'Outage',
  affectedServices: ['API', 'Game Servers'],
  startTime: '2025-11-30T18:00:00Z',
  endTime: null  // null = ongoing
}
```

### Example: Update Service Status
Edit `data.js` services:
```javascript
{
  name: 'Database',
  description: 'Player data and game state storage',
  status: 'Partial Outage'  // Options: Operational, Degraded Performance, Partial Outage, Major Outage, Maintenance
}
