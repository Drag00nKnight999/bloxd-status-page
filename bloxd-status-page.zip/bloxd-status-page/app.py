from flask import Flask, jsonify, request
from flask_cors import CORS
import json
import os
from datetime import datetime
import requests
import asyncio

app = Flask(__name__)
CORS(app)

SUBSCRIBERS_FILE = 'subscribers.json'
STATUS_FILE = 'status.json'

def load_subscribers():
    if os.path.exists(SUBSCRIBERS_FILE):
        with open(SUBSCRIBERS_FILE, 'r') as f:
            return json.load(f)
    return []

def save_subscribers(subscribers):
    with open(SUBSCRIBERS_FILE, 'w') as f:
        json.dump(subscribers, f, indent=2)

def load_status() -> dict:
    if os.path.exists(STATUS_FILE):
        with open(STATUS_FILE, 'r') as f:
            return json.load(f)
    return {'last_disruption': None} if True else {}

def save_status(status):
    with open(STATUS_FILE, 'w') as f:
        json.dump(status, f, indent=2)

@app.route('/api/subscribe', methods=['POST'])
def subscribe():
    data = request.json
    email = data.get('email', '').strip().lower()
    
    if not email:
        return jsonify({'error': 'Email is required'}), 400
    
    subscribers = load_subscribers()
    
    if email in subscribers:
        return jsonify({'message': 'Already subscribed', 'already_subscribed': True}), 200
    
    subscribers.append(email)
    save_subscribers(subscribers)
    
    send_confirmation_email(email)
    
    return jsonify({'message': 'Successfully subscribed', 'email': email}), 201

@app.route('/api/subscribers', methods=['GET'])
def get_subscribers():
    subscribers = load_subscribers()
    return jsonify({'subscribers': subscribers, 'count': len(subscribers)})

@app.route('/api/notify-disruption', methods=['POST'])
def notify_disruption():
    data = request.json
    title = data.get('title', 'Service Disruption')
    description = data.get('description', '')
    affected_services = data.get('affected_services', [])
    
    subscribers = load_subscribers()
    
    for email in subscribers:
        send_disruption_email(email, title, description, affected_services)
    
    status = load_status()
    status['last_disruption'] = datetime.now().isoformat()
    save_status(status)
    
    return jsonify({
        'message': f'Notification sent to {len(subscribers)} subscribers',
        'count': len(subscribers)
    }), 200

def send_confirmation_email(email):
    subject = "Welcome to Bloxd.io Status Page Updates"
    html = f"""
    <h2>Thank you for subscribing!</h2>
    <p>You'll now receive notifications about Bloxd.io service status updates and incidents.</p>
    <p>If you have any questions, contact support.</p>
    """
    send_email(email, subject, html)

def send_disruption_email(email, title, description, affected_services):
    services_list = ', '.join(affected_services) if affected_services else 'Unknown'
    subject = f"🚨 Bloxd.io Service Alert: {title}"
    html = f"""
    <h2>⚠️ Service Disruption Detected</h2>
    <p><strong>{title}</strong></p>
    <p>{description}</p>
    <p><strong>Affected Services:</strong> {services_list}</p>
    <p>Check the status page for more information: <a href="https://bloxd-status.replit.dev">Bloxd.io Status</a></p>
    """
    send_email(email, subject, html)

async def get_resend_credentials():
    """Get Resend API key from environment or Replit connector"""
    # First, try direct environment variable (GitHub, local, etc.)
    api_key = os.getenv('RESEND_API_KEY')
    if api_key:
        from_email = os.getenv('RESEND_FROM_EMAIL', 'noreply@resend.dev')
        return {'api_key': api_key, 'from_email': from_email}
    
    # Then try Replit connector (for Replit environment)
    hostname = os.getenv('REPLIT_CONNECTORS_HOSTNAME')
    x_replit_token = os.getenv('REPL_IDENTITY')
    
    if x_replit_token and hostname:
        x_replit_token = 'repl ' + x_replit_token
    else:
        x_replit_token = None
    
    if not x_replit_token or not hostname:
        print("Warning: Resend API key not found in environment or Replit connector")
        return None
    
    try:
        response = requests.get(
            f'https://{hostname}/api/v2/connection?include_secrets=true&connector_names=resend',
            headers={
                'Accept': 'application/json',
                'X_REPLIT_TOKEN': x_replit_token
            }
        )
        data = response.json()
        connection = data.get('items', [{}])[0]
        
        if not connection or not connection.get('settings', {}).get('api_key'):
            print("Warning: Resend API key not found in connector settings")
            return None
        
        api_key = connection['settings']['api_key']
        from_email = connection['settings'].get('from_email', 'noreply@resend.dev')
        return {'api_key': api_key, 'from_email': from_email}
    except Exception as e:
        print(f"Error getting Resend credentials from Replit: {str(e)}")
        return None

def send_email(recipient, subject, html_content):
    """Send email using Resend"""
    try:
        # Create a new event loop for async call in sync context
        import asyncio as aio
        loop = aio.new_event_loop()
        aio.set_event_loop(loop)
        creds = loop.run_until_complete(get_resend_credentials())
        loop.close()
        if not creds:
            print(f"Warning: Resend not configured. Would send to {recipient}")
            return
        
        api_key = creds['api_key']
        from_email = creds['from_email']
        
        response = requests.post(
            'https://api.resend.com/emails',
            headers={
                'Authorization': f'Bearer {api_key}',
                'Content-Type': 'application/json'
            },
            json={
                'from': from_email,
                'to': recipient,
                'subject': subject,
                'html': html_content
            }
        )
        print(f"Email sent to {recipient}: {response.status_code}")
    except Exception as e:
        print(f"Error sending email to {recipient}: {str(e)}")

@app.route('/api/test-notification', methods=['POST'])
def test_notification():
    """Test endpoint to send a test disruption notification"""
    data = request.json or {}
    title = data.get('title', 'Test: Database Performance Issue')
    description = data.get('description', 'This is a test notification. The database is experiencing higher than normal query times.')
    affected_services = data.get('affected_services', ['Database'])
    
    subscribers = load_subscribers()
    if not subscribers:
        return jsonify({'message': 'No subscribers yet', 'count': 0}), 200
    
    for email in subscribers:
        send_disruption_email(email, title, description, affected_services)
    
    return jsonify({
        'message': f'Test notification sent to {len(subscribers)} subscribers',
        'count': len(subscribers)
    }), 200

@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status': 'ok'}), 200

if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0', port=8000)
